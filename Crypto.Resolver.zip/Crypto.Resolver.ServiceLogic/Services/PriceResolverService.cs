﻿using Crypto.Resolver.Contract.Models;
using Crypto.Resolver.Contract.Utilities;
using Crypto.Resolver.Repository;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace Crypto.Resolver.ServiceLogic.Services
{
    public class PriceResolverService : IPriceResolverService
    {
        private IPricingRepository _repository;
        private IConfigurationService _configurationService;

        public PriceResolverService(IPricingRepository repository, IConfigurationService configurationService)
        {
            _repository = repository;
            _configurationService = configurationService;
        }
            public async Task<ModelResponse<CurrencyPricing >> ResolveCurrencyPriceAsync(string currencycode)
        {
            string message = string.Empty;

            var currencies =await  GetCurrencies();
            if (currencies == null || currencies.ResponseResult==Result.Failure || !currencies.Output.Contains(currencycode))
                return new ModelResponse<CurrencyPricing >()
                {
                    Message = "Invalid Currency Code",
                    ResponseResult = Result.Failure
                };

            var pricingAPIContract = await GetPricingAsync(currencycode);

            try
            {
                if (pricingAPIContract.ResponseResult == Result.Success)
                {
                    var PreviousPrice = GetPreviousPrice(currencycode);
                    var PriceChange = GetPriceDifference(pricingAPIContract.Output.Ask, PreviousPrice ?? 0);

                    var pricing = _repository.Save(new Pricing()
                    {
                        Currency = currencycode,
                        Price = pricingAPIContract.Output.Ask,
                        PriceTimeStamp = pricingAPIContract.Output.Timestamp,
                        PreviousPrice = PreviousPrice,
                        UpdatedTime = DateTime.UtcNow,
                    });


                    return new ModelResponse<CurrencyPricing >()
                    {
                        Message = message,
                        ResponseResult = Result.Success,
                        Output = new CurrencyPricing ()
                        {
                            PricingId = pricing.PricingId,
                            UpdatedTime = pricing.UpdatedTime,
                            Currency = pricing.Currency,
                            PreviousPrice = PreviousPrice,
                            Price = pricing.Price,
                            PriceChange = PriceChange,
                            PriceChangePercentage = PriceChange * (decimal)0.01,
                            PriceTimeStamp = pricing.PriceTimeStamp,
                            Bid= pricingAPIContract.Output.Bid,
                            Rate= pricingAPIContract.Output.Rate
                        }

                    };
                }

            }
            catch (Exception ex)
            {
                message = "Unhandled Exception Occured " ;
            }

            return new ModelResponse<CurrencyPricing >()
            {
                Message = message,
                ResponseResult = Result.Failure
            };
        }


        public async Task<ModelResponse<string[]>> GetCurrencies()
        {
            string message = string.Empty;
            string url = $"{ _configurationService.GetConfiguration("APIs:cointree")}";

            try
            {
                using (var httpClient = new HttpClient())
                {
                    var response = httpClient.GetAsync(new Uri(url)).Result;
                    if (response.IsSuccessStatusCode)
                    {
                        var responseBody = await response.Content.ReadAsStringAsync();
                        var pricingAPIContract = JsonConvert.DeserializeObject<PricingAPIContract[]>(responseBody);
                        return new ModelResponse<string[]>()
                        {
                            Message = message,
                            Output = pricingAPIContract.Select(e => e.Buy).ToArray(),
                            ResponseResult = Result.Success
                        };
                    }

                    message = "Request was not succesful";
                }
            }
            catch (Exception ex)
            {
                message = "Unhandled Exception Occured";
            }

            return new ModelResponse<string[]>()
            {
                Message = message,
                ResponseResult = Result.Failure
            };
        }

        public IEnumerable<CurrencyPricing> CurrencyPricing(PricingAPIContract[] pricingModel)
        {
            foreach(var currencyModel in pricingModel)
            {

                var PreviousPrice = GetPreviousPrice(currencyModel.Buy);
                var PriceChange = GetPriceDifference(currencyModel.Ask, PreviousPrice ?? 0);

                var pricing = _repository.Save(new Pricing()
                {
                    Currency = currencyModel.Buy,
                    Price = currencyModel.Ask,
                    PriceTimeStamp = currencyModel.Timestamp,
                    PreviousPrice = PreviousPrice,
                    UpdatedTime = DateTime.UtcNow,
                });

                yield return new CurrencyPricing()
                {

                    PricingId = pricing.PricingId,
                    UpdatedTime = pricing.UpdatedTime,
                    Currency = pricing.Currency,
                    PreviousPrice = PreviousPrice,
                    Price = pricing.Price,
                    PriceChange = PriceChange,
                    PriceChangePercentage = PriceChange * (decimal)0.01,
                    PriceTimeStamp = pricing.PriceTimeStamp,
                    Bid = currencyModel.Bid,
                    Rate = currencyModel.Rate
                };
            }
           
        }

        public async Task<ModelResponse<CurrenciesModel>> GetCurrenciesModel()
        {
            string message = string.Empty;
            string url = $"{ _configurationService.GetConfiguration("APIs:cointree")}";

            try
            {
                using (var httpClient = new HttpClient())
                {
                    var response = httpClient.GetAsync(new Uri(url)).Result;
                    if (response.IsSuccessStatusCode)
                    {
                        var responseBody = await response.Content.ReadAsStringAsync();
                        var pricingModel = JsonConvert.DeserializeObject<PricingAPIContract[]>(responseBody);

                        var outputModel = CurrencyPricing(pricingModel);
                      
                        return new ModelResponse<CurrenciesModel>()
                        {
                            Message = message,
                            Output = new CurrenciesModel() { CurrencyPricing= outputModel.ToList() },
                            ResponseResult = Result.Success
                        };
                    }

                    message = "Request was not succesful";
                }
            }
            catch (Exception ex)
            {
                message = "Unhandled Exception Occured";
            }

            return new ModelResponse<CurrenciesModel>()
            {
                Message = message,
                ResponseResult = Result.Failure
            };
        }
        public async Task<ModelResponse<PricingAPIContract>> GetPricingAsync(string currencycode)
        {
            string message = string.Empty;
            string url = $"{ _configurationService.GetConfiguration("APIs:cointree")}//{currencycode}";

            try
            {
                using (var httpClient = new HttpClient())
                {
                    var response = httpClient.GetAsync(new Uri(url)).Result;
                    if (response.IsSuccessStatusCode)
                    {
                        var responseBody = await response.Content.ReadAsStringAsync();
                        var pricingAPIContract = JsonConvert.DeserializeObject<PricingAPIContract>(responseBody);
                        return new ModelResponse<PricingAPIContract>()
                        {
                            Message = message,
                            Output = pricingAPIContract,
                            ResponseResult = Result.Success
                        };
                    }

                    message = "Request was not succesful";
                }
            }
            catch (Exception ex)
            {
                message = "Unhandled Exception Occured";
            }

            return new ModelResponse<PricingAPIContract>()
            {
                Message = message,
                ResponseResult = Result.Failure
            };
        }
        public decimal? GetPreviousPrice(string currencycode)
        {
            var pricing = _repository.GetAll().Where(e => e.Currency == currencycode).OrderByDescending(e => e.PricingId);

            if (pricing.Any())
                return pricing.FirstOrDefault().Price;

            return null;
        }

        public decimal GetPriceDifference(decimal CurrentPrice, decimal PreviousPrice)
        {
            return CurrentPrice - PreviousPrice;
        }

        public string GetActiveCurrency()
        {
            var pricing = _repository.GetLast();
            return pricing != null ? pricing.Currency : null;
        }
    }
}
