﻿using Crypto.Resolver.Contract.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Crypto.Resolver.ServiceLogic.Services
{
    public interface IPriceResolverService
    {
        Task<ModelResponse<CurrencyPricing >> ResolveCurrencyPriceAsync(string currencycode);
        Task<ModelResponse<PricingAPIContract>> GetPricingAsync(string currency);
        Task<ModelResponse<string[]>> GetCurrencies();
        IEnumerable<CurrencyPricing> CurrencyPricing(PricingAPIContract[] pricingModel);
        Task<ModelResponse<CurrenciesModel>> GetCurrenciesModel();
        decimal? GetPreviousPrice(string currency);
        decimal GetPriceDifference(decimal CurrentPrice, decimal PreviousPrice);
        string GetActiveCurrency();
    }
}
