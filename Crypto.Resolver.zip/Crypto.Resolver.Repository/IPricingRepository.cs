﻿using Crypto.Resolver.Contract.Models;
using System.Linq;

namespace Crypto.Resolver.Repository
{
    public interface IPricingRepository
    {
        IQueryable<Pricing> GetAll();

        Pricing GetLast();

        Pricing Insert(Pricing pricing);

        Pricing Update(Pricing pricing);

        Pricing Save(Pricing pricing);
    }
}
