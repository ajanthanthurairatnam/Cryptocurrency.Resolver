﻿using Crypto.Resolver.Contract.Models;
using Crypto.Resolver.ServiceLogic.Services;
using Microsoft.Extensions.Configuration;

namespace Crypto.Resolver.API.Services
{
    public class ConfigurationService : IConfigurationService
    {
        private IConfiguration _config;
        public ConfigurationService(IConfiguration config)
        {
            _config = config;
        }

        public string GetConfiguration(string Key)
        {
            return _config.GetSection(Key).Value;
        }
    }
}
