﻿using System.Diagnostics;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Crypto.Resolver.API.Models;
using Crypto.Resolver.ServiceLogic.Services;
using Crypto.Resolver.Contract.Models;

namespace Crypto.Resolver.API.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IPriceResolverService _priceResolverService;

        public HomeController(ILogger<HomeController> logger, IPriceResolverService priceResolverService)
        {
            _logger = logger;
            _priceResolverService = priceResolverService;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public IActionResult GetCurrencies()
        {
            return Json( new CurrenyViewModel() { Currencies = _priceResolverService.GetCurrencies().Result.Output.ToList(), ActiveCurrency = _priceResolverService.GetActiveCurrency() });
        }

        [HttpGet]
        public IActionResult GetCurrenciesModel()
        {
            return Json(_priceResolverService.GetCurrenciesModel());
        }


        [HttpGet]
        public IActionResult GetCurrencyPrice(string currencycode)
        {
            return Json(_priceResolverService.ResolveCurrencyPriceAsync(currencycode));
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
