import * as React from "react";
import { makeStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import Button from '@material-ui/core/Button';
import List from '@material-ui/core/List';
import ListItem from "@material-ui/core/ListItem/ListItem";
import ListItemIcon from "@material-ui/core/ListItemIcon/ListItemIcon";
import ListItemText from "@material-ui/core/ListItemText/ListItemText";
import { useEffect, useState } from "react";
import { FormControl, InputLabel, Select, FormHelperText } from "@material-ui/core";

const useStyles = makeStyles({
  root: {
    minWidth: 275,
  },
  bullet: {
    display: 'inline-block',
    margin: '0 2px',
    transform: 'scale(0.8)',
  },
  title: {
    fontSize: 14,
  },
  pos: {
    marginBottom: 12,
  },
});


interface ICurrenciesModel
{
  activeCurrency:string,
  currencies:string[]
}

interface IPriceResponse
{
  success:boolean,
  message:string,
  price?:Number,
  previousPrice?:Number,
  priceChange?:Number,
  priceChangePercentage?:Number,
  bid?:Number,
  rate?:Number,
 
}


export default function Currency() {
  const classes = useStyles();
  const [seconds, setSeconds] = useState(0);
  const [CurrenciesModel, setCurrenciesModel] = useState<ICurrenciesModel>(null);
  const [priceResponse, setModelResponse] = useState<IPriceResponse>({success:false,message:"loading"});
 

  useEffect(() => {
    getCurrenciesModel();
  }, []);


  const refreshModel=(activeCurrency:string)=>{
    const interval = setInterval(() => {
      if(activeCurrency!=null && activeCurrency!="")
      {
        setSeconds(seconds => seconds + 1);
        if(seconds%5==0){
          getCurrencyPrice(activeCurrency);
        }
      }
    }, 5000);
    return () => {clearInterval(interval)};
  }
  
  const getCurrenciesModel=()=>{
    $.getJSON("/Home/GetCurrencies", function(model:ICurrenciesModel) {
      if(model.activeCurrency!=null && model.activeCurrency.length>0){
        refreshModel(model.activeCurrency);
      }
        setCurrenciesModel(model);
      });
    };

    const getCurrencyPrice=(currencycode:string)=>{
      $.getJSON(`/Home/GetCurrencyPrice?currencycode=${currencycode}`, function(model:any) {
        if(model){
          const isSuccess=(model.result && model.result.responseResult==0);
         const message=model.result?model.result.message:`Unable to load values for Currency ${currencycode}`;
         setModelResponse(
           {
             success:isSuccess,
             message:message,
             price:isSuccess?model.result.output.price:null,
             previousPrice:isSuccess && model.result.output.previousPrice!=null?model.result.output.previousPrice:null,
             bid:isSuccess?model.result.output.bid:null,
             priceChange:isSuccess?model.result.output.priceChange:null,
             priceChangePercentage:isSuccess?model.result.output.priceChangePercentage:null,
             rate:isSuccess?model.result.output.rate:null
           })
        }
        else
        {
          setModelResponse({success:false,message:`Unable to load values for Currency ${currencycode}`})
        }
        });
      };
  
    const handleChange = (event:any) => {
      let currenciesModel={...CurrenciesModel};
      currenciesModel.activeCurrency=event.target.value;
      setCurrenciesModel(currenciesModel);
      if(event.target.value!=""){
        getCurrencyPrice(event.target.value);
      }
      
    };
  

  return (
      <div>
       <br />
       <br />
        <Card className={classes.root}>
        <CardContent>
          <div>
          { 
       (CurrenciesModel && CurrenciesModel.currencies!=null && CurrenciesModel.currencies.length>=0) &&
       (
        <FormControl required >
        <InputLabel htmlFor="currencies">Currency</InputLabel>
        <Select
          native
          defaultValue={CurrenciesModel.activeCurrency}
          name="currency"
          onChange={handleChange}
        >
           <option aria-label="None" value="" />
          {
            CurrenciesModel.currencies.map(fbb =>
              <option key={fbb} value={fbb}>{fbb}</option>
          )};
         
        </Select>
        <FormHelperText>Required</FormHelperText>
      </FormControl>
       )
       }
       {
         !priceResponse.success &&
          <List>
          <ListItem button key={priceResponse.message}>
            <ListItemText primary={priceResponse.message} />
            </ListItem>
          </List>
       }
       {
         priceResponse.success &&
          <List>
          <ListItem button key={`Price}`}>
            <ListItemText primary={`Price :${priceResponse.price.toString()}`} />
            </ListItem>
            <ListItem button key={`Bid}`}>
            <ListItemText primary={`Bid :${priceResponse.bid.toString()}`} />
            </ListItem>
            <ListItem button key={`Rate}`}>
            <ListItemText primary={`Rate :${priceResponse.rate.toString()}`} />
            </ListItem>
            <ListItem button key={`PreviousPrice}`}>
            <ListItemText primary={`Previous Price :${priceResponse.previousPrice!=null?priceResponse.previousPrice.toString():""}`} />
            </ListItem>
            <ListItem button key={`PriceChange}`} >
            <ListItemText primary={`Price Change :${priceResponse.priceChange.toString()}`}  />
            </ListItem>
            <ListItem button key={`PriceChangePercentage}`}>
            <ListItemText primary={`Price Change Percentage :${priceResponse.priceChangePercentage.toString()}`}  />
            </ListItem>
           
          </List>
       }
          </div>
          
        </CardContent>
     
    </Card>

      </div>
    
  );
}
