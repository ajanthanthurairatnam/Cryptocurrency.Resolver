import * as React from "react";
import Button from '@material-ui/core/Button';

export interface HelloProps {
 
}

export const Hello = (props: HelloProps) => (
  <h1>
    Hello World <br />
  </h1>
);  
