﻿using System.Security.Authentication;
using Crypto.Resolver.Contract.Models;
using Crypto.Resolver.ServiceLogic.Services;
using MongoDB.Driver;


namespace Crypto.Resolver.Storage.Services
{
    public class MongoDbService : IMongoDbService
    {
        private string _connectionString;
        private string _db;
        private string _collection;

        public MongoDbService(IConfigurationService configurationService)
        {
            _connectionString = configurationService.GetConfiguration("Connection:ConnectionString");
            _db = configurationService.GetConfiguration("Connection:Db");
            _collection = configurationService.GetConfiguration("Connection:Collection");
        }

        public MongoClient CreateMongoClient()
        {
            MongoClientSettings settings = MongoClientSettings.FromUrl(
             new MongoUrl(_connectionString)
           );
            settings.SslSettings =
              new SslSettings() { EnabledSslProtocols = SslProtocols.Tls12 };
            return new MongoClient(settings);
        }

        public IMongoDatabase GetMongoDatabase(MongoClient mongoClient)
        {
            return mongoClient.GetDatabase(_db);
        }

        public IMongoCollection<Pricing> GetMongoCollection(IMongoDatabase mongoDatabase)
        {
            return mongoDatabase.GetCollection<Pricing>(_collection);
        }
    }
}
