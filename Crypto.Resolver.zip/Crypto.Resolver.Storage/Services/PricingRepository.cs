﻿using System;
using System.Linq;
using Crypto.Resolver.Contract.Models;
using Crypto.Resolver.Repository;
using Crypto.Resolver.Storage.Services;
using MongoDB.Driver;


namespace Crypto.Resolver.Storage
{
    public class PricingRepository : IPricingRepository
    {
        private readonly IMongoDbService _mongoDbService;
        private readonly MongoClient _mongoClient;
        private IMongoDatabase _mongoDatabase;
        private IMongoCollection<Pricing> _collection;

        public PricingRepository(IMongoDbService mongoDbService)
        {
            _mongoDbService = mongoDbService;
            _mongoClient= _mongoDbService.CreateMongoClient();
            _mongoDatabase = _mongoDbService.GetMongoDatabase(_mongoClient);
            _collection = _mongoDbService.GetMongoCollection(_mongoDatabase);
        }

        public IQueryable<Pricing> GetAll()
        {
            var mongoClient = _mongoDbService.CreateMongoClient();
            var mongoDatabase = _mongoDbService.GetMongoDatabase(mongoClient);


            

            var collection = _collection.AsQueryable<Pricing>().Select(e=>new Pricing() 
                                                        {
                                                            Currency=e.Currency, 
                                                            PreviousPrice=e.PreviousPrice,
                                                            Price=e.Price,
                                                            PriceTimeStamp=e.PriceTimeStamp,
                                                            PricingId=e.PricingId,
                                                            UpdatedTime=e.UpdatedTime
                                                        });
            return collection;
        }

        public Pricing GetLast()
        {
           return GetAll().OrderByDescending(e=>e.PricingId).FirstOrDefault();
        }

        public Pricing Insert(Pricing pricing)
        {
            pricing.PricingId = GetAll().Count();
            _collection.InsertOne(pricing);
           return pricing;
        }

        public Pricing Save(Pricing pricing)
        {
            var pricingModel = GetAll().Where(e => e.Currency == pricing.Currency).FirstOrDefault();
            if (pricingModel==null || pricingModel.PricingId!=null)
                return Insert(pricing);

            pricing.PricingId = pricingModel.PricingId;
            return Update(pricing);
        }

        public Pricing Update(Pricing pricing)
        {
            var filter = Builders<Pricing>.Filter.Eq("PricingId", pricing.PricingId);
            var update = Builders<Pricing>.Update
                                          .Set("Currency", pricing.Currency)
                                          .Set("Price", pricing.Price)
                                          .Set("PriceTimeStamp", pricing.PriceTimeStamp)
                                          .Set("UpdatedTime", pricing.UpdatedTime)
                                          .Set("PreviousPrice", pricing.PreviousPrice);

            _collection.UpdateOne(filter, update);

            return pricing;
        }
    }
}
