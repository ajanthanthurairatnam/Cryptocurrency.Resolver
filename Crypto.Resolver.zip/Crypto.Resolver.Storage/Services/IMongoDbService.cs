﻿using Crypto.Resolver.Contract.Models;
using MongoDB.Driver;

namespace Crypto.Resolver.Storage.Services
{
    public interface IMongoDbService
    {
        MongoClient CreateMongoClient();

        IMongoDatabase GetMongoDatabase(MongoClient mongoClient);

        IMongoCollection<Pricing> GetMongoCollection(IMongoDatabase mongoDatabase);

    }
}
