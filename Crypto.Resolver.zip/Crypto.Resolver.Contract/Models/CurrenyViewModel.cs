﻿using System.Collections.Generic;

namespace Crypto.Resolver.Contract.Models
{
    public class CurrenyViewModel
    {
        public List<string> Currencies { get; set; }
        public string ActiveCurrency { get; set; }
    }
}
