﻿using System;

namespace Crypto.Resolver.Contract.Models
{
    public class Pricing
    {
        public int? PricingId { get; set; }
        public string Currency { get; set; }
        public decimal Price { get; set; }
        public DateTimeOffset PriceTimeStamp { get; set; }
        public DateTime UpdatedTime { get; set; }
        public decimal? PreviousPrice { get; set; }

    }
}
