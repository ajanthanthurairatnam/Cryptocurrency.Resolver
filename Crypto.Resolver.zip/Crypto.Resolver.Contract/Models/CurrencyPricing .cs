﻿namespace Crypto.Resolver.Contract.Models
{
    public class CurrencyPricing : Pricing
    {
        public decimal PriceChange { get; set; }
        public decimal PriceChangePercentage { get; set; }
        public decimal Bid { get; set; }
        public decimal Rate { get; set; }


    }
}
