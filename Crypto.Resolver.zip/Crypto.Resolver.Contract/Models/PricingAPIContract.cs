﻿using System;
using Newtonsoft.Json;

namespace Crypto.Resolver.Contract.Models
{
    public class PricingAPIContract
    {
        [JsonProperty("sell")]
        public string Sell { get; set; }

        [JsonProperty("buy")]
        public string Buy { get; set; }

        [JsonProperty("ask")]
        public decimal Ask { get; set; }

        [JsonProperty("bid")]
        public decimal Bid { get; set; }

        [JsonProperty("rate")]
        public decimal Rate { get; set; }

        [JsonProperty("spotRate")]
        public decimal SpotRate { get; set; }

        [JsonProperty("market")]
        public string Market { get; set; }

        [JsonProperty("timestamp")]
        public DateTimeOffset Timestamp { get; set; }

        [JsonProperty("rateType")]
        public string RateType { get; set; }

        [JsonProperty("rateSteps")]
        public object RateSteps { get; set; }
    }
}
