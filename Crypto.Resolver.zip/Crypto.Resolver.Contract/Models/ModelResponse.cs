﻿using Crypto.Resolver.Contract.Utilities;

namespace Crypto.Resolver.Contract.Models
{
    public class ModelResponse<T> where T : class
    {
        public Result ResponseResult { get; set; }
        public string Message { get; set; }
        public T Output { get; set; }

    }
}
