﻿using System.Collections.Generic;

namespace Crypto.Resolver.Contract.Models
{
    public class CurrenciesModel
    {
        public List<CurrencyPricing> CurrencyPricing { get; set; }
       
    }
}
