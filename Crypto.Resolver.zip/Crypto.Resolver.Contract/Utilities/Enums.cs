﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Crypto.Resolver.Contract.Utilities
{
    public enum Result
    {
        Success,
        Failure
    }
}
